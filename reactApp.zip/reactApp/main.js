import React from 'react';
import ReactDOM from 'react-dom';
//import './index.css';
import axios from 'axios';

class NameForm extends React.Component {

  constructor(props) {
    super(props);
    this.state = {nomeEmpresa: ''};
    this.state = {numAcoes: ''};

    this.handleChangeNomeEmpresa = this.handleChangeNomeEmpresa.bind(this);
    this.handleChangeNumAcoes = this.handleChangeNumAcoes.bind(this);


    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChangeNomeEmpresa(event) {
    this.setState({nomeEmpresa: event.target.value});
  }

  handleChangeNumAcoes(event) {
    this.setState({numAcoes: event.target.value});
  }


  handleSubmit(event) {
    event.preventDefault();

  var valorInvestido = this.state.numAcoes;
  var resultado = this.refs.resultado;
  var precoAcao = 0;
  var acao = this.refs.precoAcao;

  if (valorInvestido < 0){
    resultado.value = 'Valor deve ser positivo.';
  }

  else {

    var query = 'https://query.yahooapis.com/v1/public/yql?q=select%20LastTradePriceOnly%20from%20yahoo.finance.quote%20where%20symbol%20%3D%20%22';
    query += this.state.nomeEmpresa;
    query += '%22&format=json&diagnostics=true&env=store%3A%2F%2Fdatatables.org%2Falltableswithkeys';

    axios.get(query)
    .then(function (resp) {
        precoAcao = resp.data.query.results.quote.LastTradePriceOnly;
        if (precoAcao == null)
        {
          resultado.value = 'Codigo da Empresa Indisponivel';
        }
        else {
          resultado.value = Math.floor(valorInvestido / precoAcao);
          acao.value = '$ ' +  precoAcao;
        }
    });
  }

}

  render() {
    return (
      <form onSubmit={this.handleSubmit}>

        <label>
          Codigo da Empresa:
          <input type="text" className="form-control" value={this.state.value} onChange={this.handleChangeNomeEmpresa} />
        </label><br/>
        <label>
          Valor Investido ($):
          <input type='number' className="form-control" value={this.state.value} onChange={this.handleChangeNumAcoes} />
        </label><br/>
        <input type="submit" className="btn btn-primary" value="Enviar" />
        <div className="row">
          <div className="col-md-3" />
          <div className="col-md-3">
            <label>Numero de Acoes:</label>
            <input className="form-control" type="text"  ref="resultado" disabled/>
          </div>
          <div className="col-md-3">
            <label>Preco da Acao:</label>
            <input className="form-control" type="text"  ref="precoAcao" disabled/>
          </div>

        </div>

      </form>
    );
  }
}

ReactDOM.render(
  <NameForm />,
  document.getElementById('root')
);
